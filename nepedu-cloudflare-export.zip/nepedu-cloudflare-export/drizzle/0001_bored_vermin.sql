CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`code` varchar(16) NOT NULL,
	`applicantName` varchar(100) NOT NULL,
	`kakaoNick` varchar(100) NOT NULL,
	`affiliation` varchar(150) NOT NULL DEFAULT '',
	`contact` varchar(150) NOT NULL DEFAULT '',
	`motivation` text,
	`status` enum('pending','approved','rejected','completed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`),
	CONSTRAINT `applications_code_uq` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `courses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`category` varchar(60) NOT NULL DEFAULT '일반',
	`summary` varchar(300) NOT NULL DEFAULT '',
	`description` text NOT NULL,
	`instructor` varchar(100) NOT NULL DEFAULT '',
	`location` varchar(200) NOT NULL DEFAULT '',
	`requirements` text,
	`startAt` timestamp NOT NULL,
	`endAt` timestamp NOT NULL,
	`applyDeadline` timestamp NOT NULL,
	`capacity` int NOT NULL DEFAULT 30,
	`status` enum('draft','open','closed','ongoing','completed') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `courses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `survey_answers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`responseId` int NOT NULL,
	`questionId` int NOT NULL,
	`value` text NOT NULL,
	CONSTRAINT `survey_answers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `survey_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderIndex` int NOT NULL DEFAULT 0,
	`text` varchar(500) NOT NULL,
	`type` enum('rating','single','multiple','text') NOT NULL,
	`options` text,
	`required` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `survey_questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `survey_responses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`applicationId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `survey_responses_id` PRIMARY KEY(`id`),
	CONSTRAINT `survey_responses_app_uq` UNIQUE(`applicationId`)
);
--> statement-breakpoint
CREATE INDEX `applications_course_idx` ON `applications` (`courseId`);--> statement-breakpoint
CREATE INDEX `survey_answers_q_idx` ON `survey_answers` (`questionId`);--> statement-breakpoint
CREATE INDEX `survey_answers_r_idx` ON `survey_answers` (`responseId`);--> statement-breakpoint
CREATE INDEX `survey_responses_course_idx` ON `survey_responses` (`courseId`);