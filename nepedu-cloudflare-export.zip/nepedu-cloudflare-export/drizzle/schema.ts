import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** 교육 과정 */
export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  category: varchar("category", { length: 60 }).default("일반").notNull(),
  summary: varchar("summary", { length: 300 }).default("").notNull(),
  description: text("description").notNull(),
  instructor: varchar("instructor", { length: 100 }).default("").notNull(),
  location: varchar("location", { length: 200 }).default("").notNull(),
  requirements: text("requirements"),
  startAt: timestamp("startAt").notNull(),
  endAt: timestamp("endAt").notNull(),
  applyDeadline: timestamp("applyDeadline").notNull(),
  capacity: int("capacity").default(30).notNull(),
  /** draft: 준비중(비공개), open: 모집중, closed: 모집마감, ongoing: 진행중, completed: 교육종료 */
  status: mysqlEnum("status", ["draft", "open", "closed", "ongoing", "completed"])
    .default("draft")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

/** 교육 신청 */
export const applications = mysqlTable(
  "applications",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull(),
    /** 신청자에게 안내되는 신청번호 (설문 본인 확인에 사용) */
    code: varchar("code", { length: 16 }).notNull(),
    applicantName: varchar("applicantName", { length: 100 }).notNull(),
    kakaoNick: varchar("kakaoNick", { length: 100 }).notNull(),
    affiliation: varchar("affiliation", { length: 150 }).default("").notNull(),
    contact: varchar("contact", { length: 150 }).default("").notNull(),
    motivation: text("motivation"),
    status: mysqlEnum("status", ["pending", "approved", "rejected", "completed"])
      .default("pending")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  t => [
    uniqueIndex("applications_code_uq").on(t.code),
    index("applications_course_idx").on(t.courseId),
  ]
);

export type Application = typeof applications.$inferSelect;

/** 설문 문항 (모든 교육 공통) */
export const surveyQuestions = mysqlTable("survey_questions", {
  id: int("id").autoincrement().primaryKey(),
  orderIndex: int("orderIndex").default(0).notNull(),
  text: varchar("text", { length: 500 }).notNull(),
  /** rating: 1~5 별점, single: 단일선택, multiple: 복수선택, text: 주관식 */
  type: mysqlEnum("type", ["rating", "single", "multiple", "text"]).notNull(),
  /** single/multiple 선택지 (JSON 문자열 배열) */
  options: text("options"),
  required: boolean("required").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SurveyQuestion = typeof surveyQuestions.$inferSelect;

/** 설문 응답 (신청 1건당 1회) */
export const surveyResponses = mysqlTable(
  "survey_responses",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull(),
    applicationId: int("applicationId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  t => [
    uniqueIndex("survey_responses_app_uq").on(t.applicationId),
    index("survey_responses_course_idx").on(t.courseId),
  ]
);

/** 문항별 답변 (복수선택은 JSON 배열 문자열) */
export const surveyAnswers = mysqlTable(
  "survey_answers",
  {
    id: int("id").autoincrement().primaryKey(),
    responseId: int("responseId").notNull(),
    questionId: int("questionId").notNull(),
    value: text("value").notNull(),
  },
  t => [
    index("survey_answers_q_idx").on(t.questionId),
    index("survey_answers_r_idx").on(t.responseId),
  ]
);
